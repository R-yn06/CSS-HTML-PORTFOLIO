const express = require('express');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const PORT = 3000 || process.env.PORT;

app.get('/', async (req, res) => {
  const { success } = req.query;
  const htmlContent = await fs.readFile(path.join(__dirname, 'public', 'index.html'), 'utf8');
  
  if (success === 'true') {
    const modifiedHtml = htmlContent.replace('<body>', '<body class="with-success">');
    res.send(modifiedHtml);
  } else {
    res.send(htmlContent);
  }
});

app.post('/submit-message', (req, res) => {
  res.redirect('/?success=true');
});

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});