# Hands-on Progressive Enhancement

This folder contains hands-on exercises and examples for progressive enhancement techniques from the workshop "Build for Everyone: A Hands-On Guide to Resilient UIs".

## Contents

- `public/` - Workshop starter files and base implementation for building the progressive enhancement example
- `i_give_up/` - Complete working solution - use this when you get stuck or want to see the final result
- `server.js` - Node.js server for development
- `package.json` - Project dependencies

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   node server.js
   ```

3. Open your browser and navigate to the local server to begin the workshop activities

## Workshop Activities

The workshop teaches progressive enhancement through building an unbreakable contact form in three layers:

1. **Layer 1 - HTML Foundation**: Create semantic HTML with native form validation
2. **Layer 2 - CSS Enhancement**: Add visual styling and validation feedback
3. **Layer 3 - JavaScript Enhancement**: Add custom validation and AJAX submission

Work in the `public/` folder to build your solution, or check `i_give_up/` for the complete implementation when needed.